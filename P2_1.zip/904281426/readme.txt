For Project 2A, Frank and Matthew noticed that the page reads were not identical for the original movie.tbl file and the test version that we created. In some
cases, we noticed that the two versions ran at around more or less the same speed with occasional deviation that could be attributed to chance.

Emails
Matthew Lin: matthewallenlin@gmail.com
Kang (Frank) Chen: frankchen1698@gmail.com



